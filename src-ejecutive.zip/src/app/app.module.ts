import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {
  PerfectScrollbarModule,
  PerfectScrollbarConfigInterface,
  PERFECT_SCROLLBAR_CONFIG
} from 'ngx-perfect-scrollbar';


// CONSTANTS
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};


import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { TarjetaComponent } from './components/tarjeta/tarjeta.component';
import { GestionComponent } from './components/gestion/gestion.component';
import { DocumentacionComponent } from './components/documentacion/documentacion.component';
import { PrincipalComponent } from './components/principal/principal.component';
import { IldcComponent } from './components/ildc/ildc.component';
import { CheckboxComponent } from 'neo_supplies/elements/checkbox/checkbox.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    TarjetaComponent,
    GestionComponent,
    DocumentacionComponent,
    PrincipalComponent,
    IldcComponent
  ],
  imports: [
    BrowserModule,
    PerfectScrollbarModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
