import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IldcComponent } from './ildc.component';

describe('IldcComponent', () => {
  let component: IldcComponent;
  let fixture: ComponentFixture<IldcComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IldcComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IldcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
