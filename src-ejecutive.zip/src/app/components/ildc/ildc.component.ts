import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ildc',
  templateUrl: './ildc.component.html',
  styleUrls: ['./ildc.component.scss']
})
export class IldcComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
